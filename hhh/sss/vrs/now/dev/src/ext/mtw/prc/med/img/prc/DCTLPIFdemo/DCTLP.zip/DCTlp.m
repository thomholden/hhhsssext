function[imf,Idf] = DCTlp(IM1,k)
% LP DCT demo
%Developed by Dr.VPS Naidu

%Pyramid cinstruction
for i=1:k
    IM = reduce2d(IM1);%Gaussian pyramid
    Idf{i} = IM1 - expand2d(IM);%Laplacian pyramid
    IM1 = IM;
end
imf = IM1;
   
% image reconstruction
for i=k:-1:1
    imf = Idf{i} + expand2d(imf);
end

%======================================================
function[Ie] = expand2d(I)
mn = size(I)*2;
IDCT = dct2(I);
Ie = idct2(IDCT,[mn(1) mn(2)]);

%=====================================================
function[Id] = reduce2d(I)
mn = size(I)/2;
IDCT = dct2(I);
Id = round(idct2(IDCT(1:mn(1),1:mn(2))));
