%Function[] = DCTLPdemo()
% Developed by Dr. VPS Naidu
clear all;
close all
home;
k=2;%number of pyramid levels
IM = double(rgb2gray(imread('vpsn-us.jpg')));
%Pyramid conctruction
[imf,Idf] = DCTlp(IM,k);
e = IM-imf;%error
imshow(IM,[]);%reference image
figure
imshow(imf,[]);%reconstructed 
figure
imshow(e,[]);
RMSE = mean(e(:).^2);%root mean square error
for i=1:k
    figure(5+i);
    imshow(Idf{i},[]);%laplacian images
end
RMSE