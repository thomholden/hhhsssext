%function[] = DCTIFlp_demo()
% DCT & LP (Laplacian pyramid) based image fusion demo
%by Dr. VPS Naidu

close all;
clear all;
home;
k = 2; %pyramid levels
% insert images
imt = double(imread('saras9t.jpg'));
im1 = double(imread('saras91.jpg'));
im2 = double(imread('saras92.jpg'));

figure(1);
imshow(im1,[]);
    
figure(2);
imshow(im2,[]);

imf = DCTIFlp(im1,im2,k);
figure(3);
imshow(imf,[]);     
imd = imt-imf;
figure(4)
imshow(imd,[]);