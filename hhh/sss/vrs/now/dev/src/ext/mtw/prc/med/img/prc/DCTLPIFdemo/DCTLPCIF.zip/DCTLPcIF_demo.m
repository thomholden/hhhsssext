%function[] = DCTLPcIF_demo()
% DCT & LP (Laplacian pyramid) based image fusion demo
% by Dr. VPS Naidu

close all;
clear all;
home;
k = 2; %pyramid levels
% insert images
imt = imread('megt.jpg');
im1 = imread('meg1.jpg');
im2 = imread('meg2.jpg');

figure(1);
imshow(im1,[]);
figure(2);
imshow(im2,[]);
% fusion will start here
imf = uint8(DCTcIFlp(double(im1),double(im2),k));
%display only
figure(3);
imshow(imf,[]);     
imd = imt-imf;
figure(4)
imshow(imd,[]);