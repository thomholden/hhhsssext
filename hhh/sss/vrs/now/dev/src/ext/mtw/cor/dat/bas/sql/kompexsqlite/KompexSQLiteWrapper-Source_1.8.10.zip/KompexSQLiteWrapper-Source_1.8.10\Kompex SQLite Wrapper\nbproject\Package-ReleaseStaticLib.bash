#!/bin/bash -x

#
# Generated - do not edit!
#

# Macros
TOP=`pwd`
CND_PLATFORM=GNU-Linux-x86
CND_CONF=ReleaseStaticLib
CND_DISTDIR=dist
TMPDIR=build/${CND_CONF}/${CND_PLATFORM}/tmp-packaging
TMPDIRNAME=tmp-packaging
OUTPUT_PATH=../lib/release/KompexSQLiteWrapper_Static.a
OUTPUT_BASENAME=KompexSQLiteWrapper_Static.a
PACKAGE_TOP_DIR=release/

# Functions
function checkReturnCode
{
    rc=$?
    if [ $rc != 0 ]
    then
        exit $rc
    fi
}
function makeDirectory
# $1 directory path
# $2 permission (optional)
{
    mkdir -p "$1"
    checkReturnCode
    if [ "$2" != "" ]
    then
      chmod $2 "$1"
      checkReturnCode
    fi
}
function copyFileToTmpDir
# $1 from-file path
# $2 to-file path
# $3 permission
{
    cp "$1" "$2"
    checkReturnCode
    if [ "$3" != "" ]
    then
        chmod $3 "$2"
        checkReturnCode
    fi
}

# Setup
cd "${TOP}"
mkdir -p ../lib
rm -rf ${TMPDIR}
mkdir -p ${TMPDIR}

# Copy files and create directories and links
cd "${TOP}"
makeDirectory ${TMPDIR}/../lib/release
copyFileToTmpDir "${OUTPUT_PATH}" "${TMPDIR}/${OUTPUT_PATH}" 0644


# Generate tar file
cd "${TOP}"
rm -f ../lib/release
cd ${TMPDIR}
tar -vcf ../../../../../lib/release *
checkReturnCode

# Cleanup
cd "${TOP}"
rm -rf ${TMPDIR}
